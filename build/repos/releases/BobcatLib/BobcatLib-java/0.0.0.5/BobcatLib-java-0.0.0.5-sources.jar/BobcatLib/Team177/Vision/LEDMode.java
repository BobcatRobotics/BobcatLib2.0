// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package BobcatLib.Team177.Vision;

/** Add your docs here. */
public enum LEDMode {
  FORCEBLINK,
  FORCEOFF,
  FORCEON,
  PIPELINECONTROL
}
